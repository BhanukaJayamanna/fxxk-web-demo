<div class="modal-body">
    {{ $slot }}
</div>
