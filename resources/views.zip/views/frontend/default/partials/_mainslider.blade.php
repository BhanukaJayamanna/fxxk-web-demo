<section class="bg-secondary">
			<div class="main-slider-front">
				<img src="{{asset(asset_path('frontend/default/img/front-page/hoeschen-kruner.png'))}}" class="content-before-slide">
				<div class="carousel-front-left">
					<div class="carousel-front-left__cell" data-background-image-url="{{asset(asset_path('frontend/default/img/front-page/frau-kruner-main-photo.jpg'))}}"></div>
					<div class="carousel-front-left__cell" data-background-image-url="{{asset(asset_path('frontend/default/img/front-page/frau-kruner-main-photo.jpg'))}}"></div>
				</div>
				<div class="mein-slider-front-pfeil-container">
					<img src="{{asset(asset_path('frontend/default/img/icons/icon-pfeil-links.svg'))}}" class="main-slider-front-pfeil-links" alt="Pfeil nach links" height="26px" width="43px">
					<img src="{{asset(asset_path('frontend/default/img/icons/icon-pfeil-rechts.svg'))}}" class="main-slider-front-pfeil-rechts" alt="Pfeil nach links" height="26px" width="43px">
				</div>

				<div class="carousel-front-right">
					<div class="carousel-front-right__cell">
						<div class="carousel-front-right__content">
							<h2>Alles was deine <span class="unterline-primary">Lust</span> begehrt.</h2>
							<p>Egal ob dezenter Duft, feuchtes Höschen oder der Geruch von Schweiß - bei mir bekommst du alles!Egal ob dezenter Duft, feuchtes Höschen oder der Geruch von Schweiß - bei mir bekommst du alles!</p>
							<a href="/" class="btn btn-primary">Slip shoppen</a>
						</div>
					</div>

					<div class="carousel-front-right__cell">
						<div class="carousel-front-right__content">
							<h2>Alles was deine <span class="unterline-primary">Lust</span> begehrt.2</h2>
							<p>Egal ob dezenter Duft, feuchtes Höschen oder der Geruch von Schweiß - bei mir bekommst du alles!Egal ob dezenter Duft, feuchtes Höschen oder der Geruch von Schweiß - bei mir bekommst du alles!</p>
							<a href="/" class="btn btn-primary">Slip shoppen</a>
						</div>
					</div>

				</div>

            </div>
</section>