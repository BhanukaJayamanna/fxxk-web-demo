
<!-- ================Footer Area ================= -->
<footer class="footer-area pt-10 pb-20">
    <div class="container">
        <div class="row">

            <div class="col-lg-12 text-center">
                <p> @php echo app('general_setting')->footer_copy_right; @endphp </p>
            </div>
        </div>
    </div>
</footer>
<!-- ================End Footer Area ================= -->