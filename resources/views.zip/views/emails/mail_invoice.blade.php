@php echo $body; @endphp
@php echo $inv_details; @endphp
